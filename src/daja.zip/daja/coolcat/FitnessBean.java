package daja.coolcat;

public class FitnessBean {
	public double Min, Max, Avg;
}
